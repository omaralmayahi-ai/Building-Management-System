#!/bin/bash
echo "=============================================================================="
echo "شركة نفط الوسط - مثبت نظام السجل الرقمي الموحد للأصول (Android & iOS)"
echo "=============================================================================="
if ! command -v adb &> /dev/null; then
    echo "أداة adb غير مثبتة. يمكنك إرسال ملف MidlandOil-Assets-Registry.apk إلى هاتفك وتثبيته مباشرة."
    exit 1
fi
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "جاري تثبيت ملف APK على جهاز الأندرويد المتصل..."
adb install -r "$DIR/MidlandOil-Assets-Registry.apk"
